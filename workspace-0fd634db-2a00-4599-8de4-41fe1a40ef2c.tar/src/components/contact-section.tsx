'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

export function ContactSection() {
  const offices = [
    {
      city: "Baku, Azerbaijan",
      address: "Headquarters",
      phone: "+994 12 123 45 67",
      email: "info@azvirt.com",
      type: "main"
    },
    {
      city: "Belgrade, Serbia",
      address: "Regional Office",
      phone: "+381 11 123 45 67",
      email: "serbia@azvirt.com",
      type: "regional"
    },
    {
      city: "Istanbul, Turkey",
      address: "Liaison Office",
      phone: "+90 212 123 45 67",
      email: "turkey@azvirt.com",
      type: "liaison"
    }
  ]

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-[#0C2140] text-white">
            Get In Touch
          </Badge>
          <h2 className="text-4xl font-bold text-[#0C2140] mb-4">
            Connect With Us
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to discuss your next infrastructure project? Our team of experts is here to help you turn your vision into reality.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-[#0C2140]">Send Us a Message</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6600] focus:border-transparent"
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6600] focus:border-transparent"
                      placeholder="Doe"
                    />
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input 
                      type="email" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6600] focus:border-transparent"
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <input 
                      type="tel" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6600] focus:border-transparent"
                      placeholder="+1 234 567 8900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Company</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6600] focus:border-transparent"
                    placeholder="Your Company Name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Project Type</label>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6600] focus:border-transparent">
                    <option value="">Select project type</option>
                    <option value="road">Road Construction</option>
                    <option value="airport">Airport Infrastructure</option>
                    <option value="bridge">Bridge Engineering</option>
                    <option value="tunnel">Tunnel Construction</option>
                    <option value="other">Other Infrastructure</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea 
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6600] focus:border-transparent"
                    placeholder="Tell us about your project requirements..."
                  ></textarea>
                </div>

                <Button className="w-full bg-[#FF6600] hover:bg-[#FF6600]/90 text-white font-semibold py-3">
                  Send Message
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Office Information */}
          <div className="space-y-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-[#0C2140]">Our Offices</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {offices.map((office, index) => (
                  <div key={index} className="border-l-4 border-[#FF6600] pl-4">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-[#0C2140]">{office.city}</h4>
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${
                          office.type === 'main' ? 'bg-[#FF6600]' : 
                          office.type === 'regional' ? 'bg-[#4C6A4F]' : 'bg-[#9B111E]'
                        } text-white`}
                      >
                        {office.type}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-1">{office.address}</p>
                    <p className="text-sm text-gray-600 mb-1">{office.phone}</p>
                    <p className="text-sm text-gray-600">{office.email}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="shadow-lg bg-gradient-to-br from-[#0C2140] to-[#36454F] text-white">
              <CardHeader>
                <CardTitle className="text-xl text-white">Quick Facts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span>Founded</span>
                  <span className="font-semibold">1995</span>
                </div>
                <div className="flex justify-between">
                  <span>Employees</span>
                  <span className="font-semibold">400+</span>
                </div>
                <div className="flex justify-between">
                  <span>Countries</span>
                  <span className="font-semibold">15+</span>
                </div>
                <div className="flex justify-between">
                  <span>Projects Completed</span>
                  <span className="font-semibold">500+</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-[#0C2140]">Business Hours</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>Monday - Friday</span>
                  <span className="font-semibold">9:00 - 18:00</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span className="font-semibold">10:00 - 16:00</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span className="font-semibold">Closed</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Map Section */}
        <Card className="shadow-lg">
          <CardContent className="p-0">
            <div className="bg-gradient-to-r from-[#0C2140] to-[#36454F] text-white p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">Global Presence</h3>
              <p className="text-gray-300 mb-6">Serving clients across Azerbaijan, Serbia, and beyond</p>
              <div className="h-64 bg-white/10 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <svg className="w-16 h-16 mx-auto mb-4 text-[#FF6600]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <p className="text-gray-300">Interactive Map Coming Soon</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}