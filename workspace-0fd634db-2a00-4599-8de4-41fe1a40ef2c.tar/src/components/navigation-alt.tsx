'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Menu, X } from 'lucide-react'

export function NavigationAlt() {
  const [isOpen, setIsOpen] = useState(false)

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' }
  ]

  return (
    <nav className="fixed top-0 w-full bg-white shadow-xl z-50 border-b-2 border-[#FF6600]">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-[#0C2140] rounded-lg flex items-center justify-center hover:scale-105 transition-transform">
              <span className="text-white font-bold text-lg">A</span>
            </div>
            <div>
              <span className="text-2xl font-bold text-[#0C2140]">Azvirt</span>
              <div className="text-xs text-[#FF6600] font-semibold tracking-wide">INFRASTRUCTURE</div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-[#36454F] hover:text-[#FF6600] transition-colors font-semibold text-sm relative group py-2"
              >
                {item.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#FF6600] transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            <Button 
              variant="outline" 
              className="border-[#0C2140] text-[#0C2140] hover:bg-[#0C2140] hover:text-white font-semibold px-5 py-2"
            >
              Investor Relations
            </Button>
            <Button className="bg-[#FF6600] hover:bg-[#FF8800] text-white font-semibold px-5 py-2 shadow-md hover:shadow-lg transition-shadow">
              Get Quote
            </Button>
          </div>

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-[#0C2140] hover:bg-gray-100">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[350px] bg-white border-l-2 border-[#FF6600]">
              <div className="flex flex-col space-y-4 mt-6">
                <div className="flex items-center space-x-3 pb-4 border-b border-gray-200">
                  <div className="w-8 h-8 bg-[#0C2140] rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-sm">A</span>
                  </div>
                  <span className="text-xl font-bold text-[#0C2140]">Azvirt</span>
                </div>
                
                {navItems.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className="text-[#36454F] hover:text-[#FF6600] hover:bg-gray-50 transition-colors font-semibold text-lg py-3 px-4 rounded-lg"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.name}
                  </a>
                ))}
                
                <div className="flex flex-col space-y-3 pt-4 border-t border-gray-200">
                  <Button 
                    variant="outline" 
                    className="border-[#0C2140] text-[#0C2140] hover:bg-[#0C2140] hover:text-white font-semibold w-full py-3"
                  >
                    Investor Relations
                  </Button>
                  <Button className="bg-[#FF6600] hover:bg-[#FF8800] text-white font-semibold w-full py-3">
                    Get Quote
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}