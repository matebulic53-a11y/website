'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export function ServicesSection() {
  const services = [
    {
      title: "Road Construction",
      description: "Comprehensive highway and road construction with advanced polymer and mastic asphalt technology.",
      color: "from-[#FF6600] to-[#0C2140]",
      features: ["400+ KM constructed", "Polymer asphalt pioneer", "International standards"]
    },
    {
      title: "Airport Infrastructure",
      description: "Complete airport solutions including runways, terminals, and supporting facilities.",
      color: "from-[#4C6A4F] to-[#36454F]",
      features: ["5 international airports", "1-year completion record", "Advanced navigation systems"]
    },
    {
      title: "Bridge Engineering",
      description: "Complex bridge construction with innovative engineering solutions.",
      color: "from-[#9B111E] to-[#36454F]",
      features: ["81 bridges completed", "Advanced structural design", "Seismic resistant"]
    },
    {
      title: "Tunnel Construction",
      description: "Specialized tunnel construction for challenging terrain and conditions.",
      color: "from-[#0C2140] to-[#36454F]",
      features: ["9 tunnels completed", "Advanced ventilation", "Safety-first approach"]
    }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-[#0C2140] text-white">
            Our Expertise
          </Badge>
          <h2 className="text-4xl font-bold text-[#0C2140] mb-4">
            Comprehensive Infrastructure Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From initial survey to final execution, we deliver complete infrastructure solutions with cutting-edge technology and proven expertise.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <div className={`h-2 bg-gradient-to-r ${service.color} rounded-t-lg`}></div>
              <CardHeader>
                <CardTitle className="text-xl text-[#0C2140] group-hover:text-[#FF6600] transition-colors">
                  {service.title}
                </CardTitle>
                <CardDescription className="text-gray-600">
                  {service.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-[#FF6600] rounded-full"></div>
                      <span className="text-sm text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Technology Highlight */}
        <div className="mt-16 bg-gradient-to-r from-[#0C2140] to-[#36454F] rounded-2xl p-8 text-white">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-4">Innovation Leader</h3>
              <p className="text-gray-300 mb-4">
                First and only company in Azerbaijan to utilize polymer and mastic asphalt technology, 
                with patented activated mineral fillers by our founder Professor Ali Aliyev.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="bg-[#FF6600] text-white">Patented Technology</Badge>
                <Badge variant="secondary" className="bg-[#4C6A4F] text-white">Industry First</Badge>
                <Badge variant="secondary" className="bg-[#9B111E] text-white">R&D Leader</Badge>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-[#FF6600] mb-2">100%</div>
                <div className="text-gray-300">International Projects Revenue</div>
                <div className="text-sm text-gray-400 mt-2">As of 2022</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}