'use client'

import { AzvirtLogo, AzvirtFooterLogo, AzvirtMinimalLogo } from '@/components/azvirt-logo'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function LogoShowcase() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#0C2140] mb-4">Azvirt Logo & Button Showcase</h1>
          <p className="text-lg text-gray-600">Professional branding options for your website</p>
        </div>

        {/* Logo Variants Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-[#0C2140] mb-6">Logo Variants</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="p-6">
              <div className="text-center">
                <AzvirtLogo variant="icon" size="lg" className="mx-auto mb-4" />
                <h3 className="font-semibold text-[#0C2140] mb-2">Icon Only</h3>
                <p className="text-sm text-gray-600">Perfect for favicons and small spaces</p>
              </div>
            </Card>

            <Card className="p-6">
              <div className="text-center">
                <AzvirtLogo variant="compact" size="md" showTagline={false} className="mx-auto mb-4" />
                <h3 className="font-semibold text-[#0C2140] mb-2">Compact</h3>
                <p className="text-sm text-gray-600">Ideal for navigation headers</p>
              </div>
            </Card>

            <Card className="p-6">
              <div className="text-center">
                <AzvirtLogo variant="full" size="md" showTagline={true} className="mx-auto mb-4" />
                <h3 className="font-semibold text-[#0C2140] mb-2">Full with Tagline</h3>
                <p className="text-sm text-gray-600">Complete brand presentation</p>
              </div>
            </Card>

            <Card className="p-6">
              <div className="text-center">
                <AzvirtLogo variant="compact" size="xl" showTagline={true} className="mx-auto mb-4" />
                <h3 className="font-semibold text-[#0C2140] mb-2">Extra Large</h3>
                <p className="text-sm text-gray-600">Hero sections and featured areas</p>
              </div>
            </Card>

            <Card className="p-6">
              <div className="text-center">
                <AzvirtFooterLogo className="mx-auto mb-4" />
                <h3 className="font-semibold text-[#0C2140] mb-2">Footer Style</h3>
                <p className="text-sm text-gray-600">Optimized for footer sections</p>
              </div>
            </Card>

            <Card className="p-6">
              <div className="text-center">
                <AzvirtMinimalLogo className="mx-auto mb-4" />
                <h3 className="font-semibold text-[#0C2140] mb-2">Minimal</h3>
                <p className="text-sm text-gray-600">Clean and simple design</p>
              </div>
            </Card>
          </div>
        </div>

        {/* Button Styles Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-[#0C2140] mb-6">Button Styles</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-6">
              <CardHeader>
                <CardTitle className="text-[#0C2140]">Investor Relations Button</CardTitle>
                <CardDescription>Professional earth green design</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  variant="outline" 
                  className="w-full border-2 border-[#4C6A4F] text-[#4C6A4F] hover:bg-[#4C6A4F] hover:text-white hover:border-[#4C6A4F] font-semibold px-6 py-3 rounded-lg transition-all duration-300 shadow-md hover:shadow-lg"
                >
                  Investor Relations
                </Button>
                <div className="text-sm text-gray-600">
                  <strong>Colors:</strong> Earth Green (#4C6A4F)<br/>
                  <strong>Style:</strong> Professional outline with hover fill
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardHeader>
                <CardTitle className="text-[#0C2140]">Get Quote Button</CardTitle>
                <CardDescription>High-impact orange gradient</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full bg-gradient-to-r from-[#FF6600] to-[#FF8800] hover:from-[#FF8800] hover:to-[#FF6600] text-white font-semibold px-6 py-3 shadow-lg hover:shadow-xl transition-all duration-300">
                  Get Quote
                </Button>
                <div className="text-sm text-gray-600">
                  <strong>Colors:</strong> Orange Gradient (#FF6600 to #FF8800)<br/>
                  <strong>Style:</strong> Eye-catching gradient with shadows
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Color Palette Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-[#0C2140] mb-6">Brand Color Palette</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center">
              <div className="w-full h-20 bg-[#0C2140] rounded-lg mb-2"></div>
              <div className="text-sm font-semibold">Midnight Blue</div>
              <div className="text-xs text-gray-600">#0C2140</div>
            </div>
            <div className="text-center">
              <div className="w-full h-20 bg-[#36454F] rounded-lg mb-2"></div>
              <div className="text-sm font-semibold">Charcoal Grey</div>
              <div className="text-xs text-gray-600">#36454F</div>
            </div>
            <div className="text-center">
              <div className="w-full h-20 bg-[#FF6600] rounded-lg mb-2"></div>
              <div className="text-sm font-semibold">Vibrant Orange</div>
              <div className="text-xs text-gray-600">#FF6600</div>
            </div>
            <div className="text-center">
              <div className="w-full h-20 bg-[#9B111E] rounded-lg mb-2"></div>
              <div className="text-sm font-semibold">Ruby Red</div>
              <div className="text-xs text-gray-600">#9B111E</div>
            </div>
            <div className="text-center">
              <div className="w-full h-20 bg-[#4C6A4F] rounded-lg mb-2"></div>
              <div className="text-sm font-semibold">Earth Green</div>
              <div className="text-xs text-gray-600">#4C6A4F</div>
            </div>
          </div>
        </div>

        {/* Usage Examples */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-[#0C2140] mb-6">Usage Examples</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-6">
              <CardHeader>
                <CardTitle className="text-[#0C2140]">Navigation Header</CardTitle>
                <CardDescription>How to use the logo in navigation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-gradient-to-r from-[#0C2140] to-[#36454F] p-4 rounded-lg">
                  <AzvirtLogo variant="compact" size="md" showTagline={false} />
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <code className="bg-gray-100 p-1 rounded">
                    &lt;AzvirtLogo variant="compact" size="md" showTagline={false} /&gt;
                  </code>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardHeader>
                <CardTitle className="text-[#0C2140]">Footer Section</CardTitle>
                <CardDescription>How to use the logo in footer</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-[#0C2140] p-4 rounded-lg">
                  <AzvirtFooterLogo />
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <code className="bg-gray-100 p-1 rounded">
                    &lt;AzvirtFooterLogo /&gt;
                  </code>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center">
          <Button className="bg-[#0C2140] hover:bg-[#1A2F4A] text-white px-8 py-3">
            Back to Main Site
          </Button>
        </div>
      </div>
    </div>
  )
}