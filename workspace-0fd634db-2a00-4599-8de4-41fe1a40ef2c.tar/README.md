# 🏗️ Azvirt - International Infrastructure Contractor

A modern, professional website for Azvirt LLC, a leading international infrastructure contractor specializing in roads, airports, and complex construction projects across Azerbaijan, Serbia, and beyond.

## 🏢 About Azvirt

Azvirt LLC is a significant infrastructure contractor with a prominent presence in Azerbaijan and a growing footprint in Southeastern Europe. Founded in 1995 as a German-Azerbaijani joint venture, the company has successfully transitioned into a key international player specializing in large-scale road and airport projects.

### Key Highlights
- **Founded**: 1995
- **Expertise**: Roads, airports, bridges, tunnels
- **Innovation**: Pioneer in polymer and mastic asphalt technology
- **Global Reach**: Operations in 15+ countries
- **Strategic Focus**: Serbia (74% of advances) and Karabakh reconstruction

## ✨ Technology Stack

This website is built with cutting-edge technologies to ensure optimal performance, user experience, and maintainability:

### 🎯 Core Framework
- **⚡ Next.js 15** - The React framework for production with App Router
- **📘 TypeScript 5** - Type-safe JavaScript for better developer experience
- **🎨 Tailwind CSS 4** - Utility-first CSS framework for rapid UI development

### 🧩 UI Components & Styling
- **🧩 shadcn/ui** - High-quality, accessible components built on Radix UI
- **🎯 Lucide React** - Beautiful & consistent icon library
- **🌈 Modern Color Palette** - Custom brand colors reflecting Azvirt's identity

### 🎨 Brand Colors
- **Midnight Blue** (#0C2140) - Primary brand color
- **Charcoal Grey** (#36454F) - Secondary brand color
- **Vibrant Orange** (#FF6600) - Accent color for innovation
- **Ruby Red** (#9B111E) - Strategic projects in Serbia
- **Earth Green** (#4C6A4F) - Karabakh reconstruction projects

## 🌐 Website Features

### 🏠 Hero Section
- Compelling introduction to Azvirt's expertise
- Interactive project showcase cards
- Key statistics and achievements
- Modern gradient design with brand colors

### 🔧 Services Section
- Comprehensive infrastructure solutions showcase
- Technical expertise highlights
- Innovation leadership section
- Patented technology demonstration

### 📊 Projects Portfolio
- Strategic focus on Serbia and Karabakh
- Project status tracking (Active, Completed, Planning)
- Financial impact overview
- Regional project categorization

### 🏢 About Section
- Company timeline and milestones
- Core values and principles
- Achievement statistics
- Journey from 1995 to present

### 📞 Contact Section
- Multi-office contact information
- Project inquiry form
- Business hours and quick facts
- Global presence overview

## 🎯 Design Principles

The website follows modern design principles tailored for Azvirt's brand:

### 🎨 Visual Identity
- **Professional**: Clean, corporate design reflecting infrastructure expertise
- **Modern**: Contemporary layout with smooth animations
- **Strategic**: Color-coded project regions for clear communication
- **Responsive**: Mobile-first design for all devices

### 🎯 User Experience
- **Intuitive Navigation**: Clear menu structure with smooth scrolling
- **Performance**: Optimized loading times and interactions
- **Accessibility**: WCAG-compliant design with proper contrast
- **Engagement**: Interactive elements and visual storytelling

## 🚀 Development

### 📁 Project Structure
```
src/
├── app/                 # Next.js App Router pages
│   ├── layout.tsx      # Root layout with metadata
│   ├── page.tsx        # Homepage with all sections
│   └── globals.css     # Global styles with brand colors
├── components/          # Reusable React components
│   ├── navigation.tsx  # Main navigation component
│   ├── hero-section.tsx # Hero section with project showcase
│   ├── services-section.tsx # Services and expertise
│   ├── projects-section.tsx # Project portfolio
│   ├── about-section.tsx    # Company information
│   ├── contact-section.tsx  # Contact form and offices
│   └── footer.tsx      # Website footer
├── hooks/              # Custom React hooks
└── lib/                # Utility functions and configurations
```

### 🎨 Color System Implementation
The website implements a comprehensive color system based on Azvirt's brand identity:

```css
/* Primary Colors */
--primary: #0C2140;    /* Midnight Blue */
--secondary: #36454F;  /* Charcoal Grey */
--accent: #FF6600;     /* Vibrant Orange */

/* Strategic Colors */
--serbia: #9B111E;     /* Ruby Red */
--karabakh: #4C6A4F;   /* Earth Green */

/* Neutral Colors */
--background: #FFFFFF;
--foreground: #0C2140;
```

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000) to see the Azvirt website running.

## 📊 Key Metrics & Achievements

### Project Statistics
- **400+ km** of roads constructed
- **81 bridges** completed
- **9 tunnels** delivered
- **5 international airports** built

### Financial Performance (2022)
- **Total Revenue**: AZN 362,949 thousand
- **Serbia Focus**: 74% of customer advances
- **International Operations**: 100% of revenue from foreign contracts

### Innovation Leadership
- **First** in Azerbaijan to use polymer and mastic asphalt
- **Patented** activated mineral filler technology
- **Perfect score** (100/100) in EU tender competition

## 🌍 Strategic Markets

### Serbia
- **Ljig to Preljina Highway**: 40.3 km with 4 tunnels and 66 bridges
- **Belgrade Bypass**: Sections 4, 5, and 6 construction
- **Ruma–Šabac–Loznica Highway**: Major Sava River bridge crossing

### Karabakh Reconstruction
- **Lachin International Airport**: High-altitude airport construction
- **Fuzuli International Airport**: Accelerated construction project
- **Road Network**: Comprehensive infrastructure development

### International Projects
- **Bucharest Ring Motorway**: EU tender winner
- **Baku Formula 1 Circuit**: Iconic racing venue
- **Gabala International Airport**: Record one-year completion

## 🎯 Future Development

The website is designed for future expansion with:

### 📈 Planned Features
- **Project Gallery**: Interactive image galleries
- **News & Updates**: Company news and press releases
- **Career Portal**: Job opportunities and applications
- **Investor Relations**: Financial reports and shareholder information
- **Interactive Maps**: Project locations and global presence

### 🔧 Technical Enhancements
- **Performance Optimization**: Further speed improvements
- **SEO Enhancement**: Advanced search engine optimization
- **Analytics Integration**: User behavior tracking
- **Multilingual Support**: Multiple language versions

---

Built with modern web technologies to showcase Azvirt's excellence in infrastructure development. 🏗️✨
