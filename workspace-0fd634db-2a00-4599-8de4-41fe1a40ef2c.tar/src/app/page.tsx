import { Navigation } from '@/components/navigation'
// Uncomment one of the following to try different navigation styles:
// import { NavigationAlt } from '@/components/navigation-alt'
// import { NavigationMinimal } from '@/components/navigation-minimal'
import { HeroSection } from '@/components/hero-section'
import { ServicesSection } from '@/components/services-section'
import { ProjectsSection } from '@/components/projects-section'
import { AboutSection } from '@/components/about-section'
import { ContactSection } from '@/components/contact-section'
import { Footer } from '@/components/footer'

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Navigation Options - Currently using the gradient version */}
      <Navigation />
      {/* For alternative styles, replace <Navigation /> with:
          <NavigationAlt /> for the clean white version
          <NavigationMinimal /> for the transparent minimalist version
      */}
      
      <section id="home">
        <HeroSection />
      </section>
      
      <section id="services">
        <ServicesSection />
      </section>
      
      <section id="projects">
        <ProjectsSection />
      </section>
      
      <section id="about">
        <AboutSection />
      </section>
      
      <section id="contact">
        <ContactSection />
      </section>
      
      <Footer />
    </main>
  )
}