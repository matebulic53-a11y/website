'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Menu, X } from 'lucide-react'
import { AzvirtLogo, AzvirtMinimalLogo } from '@/components/azvirt-logo'

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' }
  ]

  return (
    <nav className="fixed top-0 w-full bg-gradient-to-r from-[#0C2140] via-[#1A2F4A] to-[#36454F] backdrop-blur-md shadow-lg z-50 border-b border-white/10">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-18">
          {/* Logo */}
          <AzvirtLogo variant="compact" size="lg" showTagline={true} />

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-gray-200 hover:text-white hover:drop-shadow-lg transition-all duration-300 font-semibold text-sm uppercase tracking-wider relative group"
              >
                {item.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#FF6600] transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            <Button 
              variant="outline" 
              className="border-2 border-[#4C6A4F] text-[#4C6A4F] hover:bg-[#4C6A4F] hover:text-white hover:border-[#4C6A4F] font-semibold px-6 py-2.5 rounded-lg transition-all duration-300 shadow-md hover:shadow-lg backdrop-blur-sm"
            >
              Investor Relations
            </Button>
            <Button className="bg-gradient-to-r from-[#FF6600] to-[#FF8800] hover:from-[#FF8800] hover:to-[#FF6600] text-white font-semibold px-6 py-2.5 shadow-lg hover:shadow-xl transition-all duration-300">
              Get Quote
            </Button>
          </div>

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-white hover:bg-white/10">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px] bg-gradient-to-b from-[#0C2140] to-[#36454F] text-white border-l border-white/20">
              <div className="flex flex-col space-y-6 mt-8">
                <AzvirtLogo variant="compact" size="md" />
                
                {navItems.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className="text-gray-200 hover:text-white hover:bg-white/10 transition-all duration-300 font-semibold text-lg py-3 px-4 rounded-lg"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.name}
                  </a>
                ))}
                
                <div className="flex flex-col space-y-3 pt-4 border-t border-white/20">
                  <Button 
                    variant="outline" 
                    className="border-2 border-[#4C6A4F] text-[#4C6A4F] hover:bg-[#4C6A4F] hover:text-white hover:border-[#4C6A4F] font-semibold w-full py-3 rounded-lg transition-all duration-300 shadow-md hover:shadow-lg backdrop-blur-sm"
                  >
                    Investor Relations
                  </Button>
                  <Button className="bg-gradient-to-r from-[#FF6600] to-[#FF8800] hover:from-[#FF8800] hover:to-[#FF6600] text-white font-semibold w-full py-3">
                    Get Quote
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}