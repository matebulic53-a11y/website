'use client'

interface AzvirtLogoProps {
  variant?: 'full' | 'icon' | 'compact'
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
  showTagline?: boolean
}

export function AzvirtLogo({ 
  variant = 'full', 
  size = 'md', 
  className = '',
  showTagline = false 
}: AzvirtLogoProps) {
  const sizeClasses = {
    sm: {
      icon: 'w-8 h-8',
      text: 'text-lg',
      tagline: 'text-xs'
    },
    md: {
      icon: 'w-10 h-10',
      text: 'text-xl',
      tagline: 'text-xs'
    },
    lg: {
      icon: 'w-12 h-12',
      text: 'text-2xl',
      tagline: 'text-sm'
    },
    xl: {
      icon: 'w-16 h-16',
      text: 'text-3xl',
      tagline: 'text-base'
    }
  }

  const currentSize = sizeClasses[size]

  const iconContent = (
    <div className={`${currentSize.icon} bg-gradient-to-br from-[#0C2140] via-[#1A2F4A] to-[#36454F] rounded-xl flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 relative overflow-hidden group`}>
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(45deg, #FF6600 25%, transparent 25%, transparent 75%, #FF6600 75%, #FF6600),
                             linear-gradient(45deg, #FF6600 25%, transparent 25%, transparent 75%, #FF6600 75%, #FF6600)`,
          backgroundSize: '8px 8px',
          backgroundPosition: '0 0, 4px 4px'
        }} />
      </div>
      
      {/* Letter A */}
      <span className="text-white font-bold z-10 relative">
        {size === 'xl' ? 'AZ' : 'A'}
      </span>
      
      {/* Accent corner */}
      <div className="absolute top-0 right-0 w-3 h-3 bg-[#FF6600] rounded-bl-lg opacity-80"></div>
    </div>
  )

  const textContent = (
    <div className="flex flex-col leading-tight">
      <span className={`${currentSize.text} font-bold text-white tracking-tight`}>
        Azvirt
      </span>
      {showTagline && (
        <span className={`${currentSize.tagline} text-[#FF6600] font-semibold tracking-wider`}>
          INFRASTRUCTURE
        </span>
      )}
    </div>
  )

  if (variant === 'icon') {
    return (
      <div className={`flex items-center ${className}`}>
        {iconContent}
      </div>
    )
  }

  if (variant === 'compact') {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        {iconContent}
        {textContent}
      </div>
    )
  }

  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      {iconContent}
      <div>
        {textContent}
        {showTagline && (
          <div className={`${currentSize.tagline} text-gray-300 font-medium mt-1`}>
            Building Tomorrow's Infrastructure
          </div>
        )}
      </div>
    </div>
  )
}

// Special footer logo variant
export function AzvirtFooterLogo({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className="w-12 h-12 bg-gradient-to-br from-[#FF6600] to-[#0C2140] rounded-xl flex items-center justify-center shadow-lg">
        <span className="text-white font-bold text-lg">A</span>
      </div>
      <div>
        <span className="text-2xl font-bold text-white">Azvirt</span>
        <div className="text-xs text-gray-300 font-medium">
          ESTABLISHED 1995
        </div>
      </div>
    </div>
  )
}

// Minimal logo for clean designs
export function AzvirtMinimalLogo({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <div className="w-8 h-8 bg-[#0C2140] rounded-lg flex items-center justify-center">
        <span className="text-white font-bold text-sm">A</span>
      </div>
      <span className="text-lg font-bold text-[#0C2140]">Azvirt</span>
    </div>
  )
}