'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#0C2140] via-[#1A2F4A] to-[#36454F]">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, #FF6600 2px, transparent 2px),
                             radial-gradient(circle at 75% 75%, #4C6A4F 2px, transparent 2px)`,
          backgroundSize: '50px 50px'
        }} />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge variant="secondary" className="bg-[#FF6600] text-white hover:bg-[#FF6600]/90">
                International Infrastructure Excellence
              </Badge>
              <h1 className="text-5xl lg:text-7xl font-bold text-white leading-tight">
                Building the Future of
                <span className="text-[#FF6600]"> Infrastructure</span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                Azvirt is a leading international infrastructure contractor specializing in roads, airports, and complex construction projects. With technical expertise spanning three decades, we deliver excellence across Azerbaijan, Serbia, and beyond.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-[#FF6600] hover:bg-[#FF6600]/90 text-white font-semibold px-8 py-3">
                Explore Projects
              </Button>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-[#0C2140] font-semibold px-8 py-3">
                About Us
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-[#FF6600]">400+</div>
                <div className="text-gray-300">KM Roads Built</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#4C6A4F]">81</div>
                <div className="text-gray-300">Bridges</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#9B111E]">9</div>
                <div className="text-gray-300">Tunnels</div>
              </div>
            </div>
          </div>

          {/* Right Content - Image Cards */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <CardContent className="p-4">
                  <div className="aspect-video bg-gradient-to-br from-[#4C6A4F] to-[#36454F] rounded-lg flex items-center justify-center">
                    <span className="text-white font-semibold">Karabakh Reconstruction</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 transform -rotate-3 hover:rotate-0 transition-transform duration-300">
                <CardContent className="p-4">
                  <div className="aspect-video bg-gradient-to-br from-[#9B111E] to-[#36454F] rounded-lg flex items-center justify-center">
                    <span className="text-white font-semibold">Serbian Highways</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 transform -rotate-3 hover:rotate-0 transition-transform duration-300">
                <CardContent className="p-4">
                  <div className="aspect-video bg-gradient-to-br from-[#FF6600] to-[#0C2140] rounded-lg flex items-center justify-center">
                    <span className="text-white font-semibold">Airport Projects</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <CardContent className="p-4">
                  <div className="aspect-video bg-gradient-to-br from-[#0C2140] to-[#36454F] rounded-lg flex items-center justify-center">
                    <span className="text-white font-semibold">Innovation Hub</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  )
}