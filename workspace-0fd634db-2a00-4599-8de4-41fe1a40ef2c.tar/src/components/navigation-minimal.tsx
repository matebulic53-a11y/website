'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Menu, X } from 'lucide-react'

export function NavigationMinimal() {
  const [isOpen, setIsOpen] = useState(false)

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' }
  ]

  return (
    <nav className="fixed top-0 w-full bg-transparent backdrop-blur-lg z-50">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-white/90 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg border border-white/20">
              <span className="text-[#0C2140] font-bold text-xl">A</span>
            </div>
            <div>
              <span className="text-3xl font-light text-white">Azvirt</span>
              <div className="text-xs text-white/70 font-light tracking-widest">ESTABLISHED 1995</div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-12">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-white/80 hover:text-white transition-all duration-300 font-light text-sm tracking-wider hover:drop-shadow-lg"
              >
                {item.name}
              </a>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button 
              variant="ghost" 
              className="text-white/90 hover:text-white hover:bg-white/10 backdrop-blur-sm font-light px-6 py-2.5 border border-white/20"
            >
              Investor Relations
            </Button>
            <Button className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white font-light px-6 py-2.5 border border-white/30">
              Get Quote
            </Button>
          </div>

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-white hover:bg-white/10">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[320px] bg-black/80 backdrop-blur-lg text-white border-l border-white/20">
              <div className="flex flex-col space-y-8 mt-8">
                <div className="flex items-center space-x-4 pb-6 border-b border-white/20">
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold text-lg">A</span>
                  </div>
                  <span className="text-2xl font-light text-white">Azvirt</span>
                </div>
                
                {navItems.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className="text-white/80 hover:text-white hover:bg-white/10 transition-all duration-300 font-light text-xl py-2 px-4 rounded-lg"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.name}
                  </a>
                ))}
                
                <div className="flex flex-col space-y-4 pt-6 border-t border-white/20">
                  <Button 
                    variant="ghost" 
                    className="text-white/90 hover:text-white hover:bg-white/10 backdrop-blur-sm font-light w-full py-3 border border-white/20"
                  >
                    Investor Relations
                  </Button>
                  <Button className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white font-light w-full py-3 border border-white/30">
                    Get Quote
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}