import { Badge } from '@/components/ui/badge'
import { AzvirtFooterLogo } from '@/components/azvirt-logo'

export function Footer() {
  return (
    <footer className="bg-[#0C2140] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <AzvirtFooterLogo />
            <p className="text-gray-300 text-sm">
              Leading international infrastructure contractor with expertise in roads, airports, and complex construction projects.
            </p>
            <div className="flex space-x-2">
              <Badge variant="secondary" className="bg-[#FF6600] text-white">Since 1995</Badge>
              <Badge variant="secondary" className="bg-[#4C6A4F] text-white">Global</Badge>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">About Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Services</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Projects</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Careers</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">News</a></li>
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Services</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Road Construction</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Airport Infrastructure</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Bridge Engineering</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Tunnel Construction</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Design & Planning</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Contact</h3>
            <div className="space-y-2 text-sm">
              <p className="text-gray-300">
                <strong>Headquarters:</strong><br />
                Baku, Azerbaijan
              </p>
              <p className="text-gray-300">
                <strong>Email:</strong><br />
                info@azvirt.com
              </p>
              <p className="text-gray-300">
                <strong>Phone:</strong><br />
                +994 12 123 45 67
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-sm text-gray-300 mb-4 md:mb-0">
              © 2025 Azvirt LLC. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-300 hover:text-[#FF6600] transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}