'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

export function AboutSection() {
  const timeline = [
    {
      year: "1995",
      title: "Company Founded",
      description: "Established as German-Azerbaijani joint venture with focus on urban road reconstruction in Baku"
    },
    {
      year: "2012",
      title: "EU Tender Victory",
      description: "Won Bucharest Ring Motorway modernization with perfect 100/100 score in EU competition"
    },
    {
      year: "2016",
      title: "Leadership Transition",
      description: "Passing of founder Professor Ali Aliyev, marking a new era of international expansion"
    },
    {
      year: "2020",
      title: "Karabakh Initiative",
      description: "Key role in the 'Great Return' program for reconstruction of liberated territories"
    },
    {
      year: "2022",
      title: "Strategic Focus",
      description: "100% revenue from international projects with strong focus on Serbia and Karabakh"
    }
  ]

  const achievements = [
    {
      number: "28",
      label: "Years of Excellence",
      description: "Since 1995"
    },
    {
      number: "15+",
      label: "Countries",
      description: "International presence"
    },
    {
      number: "100%",
      label: "International Revenue",
      description: "Global operations focus"
    },
    {
      number: "400+",
      label: "Professionals",
      description: "Expert team members"
    }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="space-y-6">
            <Badge variant="secondary" className="bg-[#0C2140] text-white">
              About Azvirt
            </Badge>
            <h2 className="text-4xl font-bold text-[#0C2140]">
              Building Tomorrow's Infrastructure Today
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              Azvirt LLC is a leading international infrastructure contractor with a proven track record of delivering complex road, airport, and bridge projects across multiple continents. From our beginnings as a state-backed joint venture to our current status as a global player, we have consistently pushed the boundaries of construction excellence.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              Our commitment to innovation is exemplified by our pioneering use of polymer and mastic asphalt technology in Azerbaijan, with patented processes that set industry standards. Today, we stand at the forefront of infrastructure development, particularly in strategic markets like Serbia and the Karabakh reconstruction initiative.
            </p>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="border-[#FF6600] text-[#FF6600]">Innovation Leader</Badge>
              <Badge variant="outline" className="border-[#4C6A4F] text-[#4C6A4F]">Global Reach</Badge>
              <Badge variant="outline" className="border-[#9B111E] text-[#9B111E]">Technical Excellence</Badge>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {achievements.map((achievement, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                <CardContent className="space-y-2">
                  <div className="text-3xl font-bold text-[#FF6600]">{achievement.number}</div>
                  <div className="font-semibold text-[#0C2140]">{achievement.label}</div>
                  <div className="text-sm text-gray-600">{achievement.description}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Timeline */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-[#0C2140] mb-4">Our Journey</h3>
            <p className="text-gray-600">Key milestones in our evolution as an infrastructure leader</p>
          </div>
          
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-[#FF6600] via-[#4C6A4F] to-[#9B111E]"></div>
            
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <div key={index} className={`relative flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className="w-1/2 pr-8">
                    <Card className="p-6 hover:shadow-lg transition-shadow">
                      <div className="space-y-2">
                        <Badge className="bg-[#0C2140] text-white">{item.year}</Badge>
                        <h4 className="text-xl font-bold text-[#0C2140]">{item.title}</h4>
                        <p className="text-gray-600">{item.description}</p>
                      </div>
                    </Card>
                  </div>
                  
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-[#FF6600] rounded-full border-4 border-white shadow-lg"></div>
                  
                  <div className="w-1/2 pl-8"></div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="bg-gradient-to-r from-[#0C2140] to-[#36454F] rounded-2xl p-12 text-white">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold mb-4">Our Core Values</h3>
            <p className="text-gray-300">The principles that guide our operations and relationships</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-[#FF6600] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h4 className="text-xl font-bold mb-2">Quality</h4>
              <p className="text-gray-300">Uncompromising commitment to excellence in every project we undertake</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-[#4C6A4F] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h4 className="text-xl font-bold mb-2">Innovation</h4>
              <p className="text-gray-300">Pioneering new technologies and methods in infrastructure development</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-[#9B111E] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h4 className="text-xl font-bold mb-2">Teamwork</h4>
              <p className="text-gray-300">Collaborative approach with partners, clients, and communities</p>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-[#0C2140]">
              Learn More About Our Approach
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}