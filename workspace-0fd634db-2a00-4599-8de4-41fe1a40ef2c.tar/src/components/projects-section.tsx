'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

export function ProjectsSection() {
  const projects = [
    {
      region: "Serbia",
      color: "border-[#9B111E]",
      badgeColor: "bg-[#9B111E]",
      projects: [
        {
          title: "Ljig to Preljina Highway",
          description: "40.3 km of modern highway construction with 4 tunnels and 66 bridges",
          status: "Active",
          highlights: ["Corridor 'Milos the Great'", "Complex terrain", "Advanced engineering"]
        },
        {
          title: "Belgrade Bypass",
          description: "Construction of sections 4, 5, and 6 of the Belgrade Bypass",
          status: "Active",
          highlights: ["Urban infrastructure", "Traffic optimization", "Multi-section project"]
        },
        {
          title: "Ruma–Šabac–Loznica Highway",
          description: "Major highway construction with Sava River bridge crossing",
          status: "Planning",
          highlights: ["River bridge", "Strategic corridor", "Regional connectivity"]
        }
      ]
    },
    {
      region: "Karabakh Reconstruction",
      color: "border-[#4C6A4F]",
      badgeColor: "bg-[#4C6A4F]",
      projects: [
        {
          title: "Lachin International Airport",
          description: "Airport construction at 1,800m altitude with extensive terrain adaptation",
          status: "Active",
          highlights: ["High-altitude construction", "Terrain engineering", "Strategic infrastructure"]
        },
        {
          title: "Fuzuli International Airport",
          description: "Accelerated construction of international airport facilities",
          status: "Completed",
          highlights: ["Fast-track completion", "Modern facilities", "Regional hub"]
        },
        {
          title: "Karabakh Road Network",
          description: "Comprehensive road infrastructure development in liberated territories",
          status: "Active",
          highlights: ["National priority", "Extensive network", "Economic development"]
        }
      ]
    },
    {
      region: "International Projects",
      color: "border-[#FF6600]",
      badgeColor: "bg-[#FF6600]",
      projects: [
        {
          title: "Bucharest Ring Motorway",
          description: "EU tender victory with perfect 100/100 score for modernization",
          status: "Completed",
          highlights: ["EU competition winner", "Perfect score", "International recognition"]
        },
        {
          title: "Baku Formula 1 Circuit",
          description: "6 km track designed for speeds up to 340 km/h",
          status: "Completed",
          highlights: ["Iconic project", "High-speed design", "International event venue"]
        },
        {
          title: "Gabala International Airport",
          description: "Complete airport construction in record one-year timeframe",
          status: "Completed",
          highlights: ["Record completion", "Full-scale airport", "Regional development"]
        }
      ]
    }
  ]

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-[#0C2140] text-white">
            Strategic Projects
          </Badge>
          <h2 className="text-4xl font-bold text-[#0C2140] mb-4">
            Global Infrastructure Portfolio
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our strategic focus on key regions delivers high-impact infrastructure projects that drive economic growth and regional development.
          </p>
        </div>

        <div className="space-y-12">
          {projects.map((region, regionIndex) => (
            <div key={regionIndex} className="space-y-6">
              <div className="flex items-center gap-4">
                <div className={`w-1 h-8 ${region.badgeColor} rounded`}></div>
                <h3 className="text-2xl font-bold text-[#0C2140]">{region.region}</h3>
                <Badge className={`${region.badgeColor} text-white`}>
                  {region.projects.filter(p => p.status === 'Active').length} Active
                </Badge>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                {region.projects.map((project, projectIndex) => (
                  <Card key={projectIndex} className={`group hover:shadow-xl transition-all duration-300 ${region.color} border-l-4`}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-[#0C2140] group-hover:text-[#FF6600] transition-colors">
                          {project.title}
                        </CardTitle>
                        <Badge 
                          variant={project.status === 'Active' ? 'default' : project.status === 'Completed' ? 'secondary' : 'outline'}
                          className={project.status === 'Active' ? 'bg-[#FF6600] hover:bg-[#FF6600]/90' : 
                                   project.status === 'Completed' ? 'bg-[#4C6A4F] hover:bg-[#4C6A4F]/90' : ''}
                        >
                          {project.status}
                        </Badge>
                      </div>
                      <CardDescription className="text-gray-600">
                        {project.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="space-y-2">
                          {project.highlights.map((highlight, highlightIndex) => (
                            <div key={highlightIndex} className="flex items-center gap-2">
                              <div className={`w-2 h-2 ${region.badgeColor.replace('bg-', 'bg-')} rounded-full`}></div>
                              <span className="text-sm text-gray-700">{highlight}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Financial Overview */}
        <div className="mt-16 bg-white rounded-2xl shadow-lg p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-[#0C2140] mb-2">Financial Impact</h3>
            <p className="text-gray-600">Strategic focus driving sustainable growth</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-[#9B111E] mb-2">74%</div>
              <div className="text-gray-600">Revenue from Serbia</div>
              <div className="text-sm text-gray-400">AZN 75,422 thousand (2022)</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#4C6A4F] mb-2">21%</div>
              <div className="text-gray-600">Revenue from Azerbaijan</div>
              <div className="text-sm text-gray-400">AZN 21,368 thousand (2022)</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#FF6600] mb-2">100%</div>
              <div className="text-gray-600">International Projects</div>
              <div className="text-sm text-gray-400">AZN 362,949 thousand total</div>
            </div>
          </div>

          <div className="text-center mt-8">
            <Button className="bg-[#0C2140] hover:bg-[#0C2140]/90 text-white">
              Download Financial Report
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}